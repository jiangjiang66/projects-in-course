/*
Navicat MySQL Data Transfer

Source Server         : aaa
Source Server Version : 50145
Source Host           : localhost:3306
Source Database       : zypx

Target Server Type    : MYSQL
Target Server Version : 50145
File Encoding         : 65001

Date: 2019-06-11 16:50:13
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tjihua
-- ----------------------------
DROP TABLE IF EXISTS `tjihua`;
CREATE TABLE `tjihua` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cdate` varchar(50) NOT NULL,
  `ctitle` varchar(255) NOT NULL,
  `uid` int(11) NOT NULL,
  `zt` varchar(50) NOT NULL DEFAULT '未审核' COMMENT '未审核、审核通过、审核不通过',
  `fk` varchar(255) NOT NULL DEFAULT '暂无',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tjihua
-- ----------------------------
INSERT INTO `tjihua` VALUES ('3', '2019-06-17', '李健2019-06-17出差计划表', '4', '未审核', '暂无');
INSERT INTO `tjihua` VALUES ('4', '2019-06-20', '李健2019-06-20出差计划表', '4', '未审核', '暂无');
INSERT INTO `tjihua` VALUES ('5', '2019-06-25', '李健2019-06-25出差计划表', '4', '未审核', '暂无');
INSERT INTO `tjihua` VALUES ('6', '2019-06-24', '李健2019-06-24出差计划表', '4', '未审核', '暂无');
INSERT INTO `tjihua` VALUES ('7', '2019-07-08', '李健2019-07-08出差计划表', '4', '未审核', '暂无');
INSERT INTO `tjihua` VALUES ('8', '2019-06-17', '李健2019-06-17出差计划表', '4', '未审核', '暂无');
INSERT INTO `tjihua` VALUES ('9', '2019-06-24', '李健2019-06-24出差计划表', '4', '未审核', '暂无');
INSERT INTO `tjihua` VALUES ('10', '2019-06-27', '李健2019-06-27出差计划表', '4', '未审核', '暂无');

-- ----------------------------
-- Table structure for tmenu
-- ----------------------------
DROP TABLE IF EXISTS `tmenu`;
CREATE TABLE `tmenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `menutext` varchar(50) NOT NULL,
  `url` varchar(255) NOT NULL,
  `pid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tmenu
-- ----------------------------
INSERT INTO `tmenu` VALUES ('1', '出差计划管理', '#', '0');
INSERT INTO `tmenu` VALUES ('2', '填写出差计划', 'addjihua.html', '1');
INSERT INTO `tmenu` VALUES ('3', '审核出差计划', 'zzzz.html', '1');
INSERT INTO `tmenu` VALUES ('4', '我的出差计划', '#', '1');
INSERT INTO `tmenu` VALUES ('5', '部门所有出差计划', '#', '1');
INSERT INTO `tmenu` VALUES ('7', '查看已经通过的出差计划', '#', '1');
INSERT INTO `tmenu` VALUES ('8', '财务管理', '#', '0');
INSERT INTO `tmenu` VALUES ('9', '填写支款单', '#', '8');
INSERT INTO `tmenu` VALUES ('10', '出差报告管理', '#', '0');
INSERT INTO `tmenu` VALUES ('11', '填写出差报告', '#', '10');
INSERT INTO `tmenu` VALUES ('12', '审核出差报告', '#', '10');
INSERT INTO `tmenu` VALUES ('13', '我的出差报告', '#', '10');
INSERT INTO `tmenu` VALUES ('14', '查看部门出差报告', '#', '10');
INSERT INTO `tmenu` VALUES ('15', '已经审核通过的出差报告', '#', '10');
INSERT INTO `tmenu` VALUES ('16', '填写报销单', '#', '8');
INSERT INTO `tmenu` VALUES ('17', '报销', '#', '8');

-- ----------------------------
-- Table structure for tmingxi
-- ----------------------------
DROP TABLE IF EXISTS `tmingxi`;
CREATE TABLE `tmingxi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `jid` int(11) NOT NULL,
  `jname` varchar(255) NOT NULL,
  `jtesk` varchar(255) NOT NULL,
  `jresult` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tmingxi
-- ----------------------------
INSERT INTO `tmingxi` VALUES ('1', '4', '', '', '');
INSERT INTO `tmingxi` VALUES ('2', '7', '测试1', '测试2', '测试3');
INSERT INTO `tmingxi` VALUES ('3', '8', '客户1', '请我吃饭', '他喝不过我');
INSERT INTO `tmingxi` VALUES ('4', '9', '客户2', '喝酒', '他肯定钻桌子');

-- ----------------------------
-- Table structure for trm
-- ----------------------------
DROP TABLE IF EXISTS `trm`;
CREATE TABLE `trm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rid` int(11) NOT NULL,
  `mid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of trm
-- ----------------------------
INSERT INTO `trm` VALUES ('1', '1', '1');
INSERT INTO `trm` VALUES ('2', '1', '3');
INSERT INTO `trm` VALUES ('3', '1', '5');
INSERT INTO `trm` VALUES ('4', '1', '10');
INSERT INTO `trm` VALUES ('5', '1', '12');
INSERT INTO `trm` VALUES ('6', '1', '14');
INSERT INTO `trm` VALUES ('7', '3', '1');
INSERT INTO `trm` VALUES ('8', '3', '2');
INSERT INTO `trm` VALUES ('9', '3', '4');
INSERT INTO `trm` VALUES ('10', '3', '8');
INSERT INTO `trm` VALUES ('11', '3', '16');
INSERT INTO `trm` VALUES ('12', '3', '10');
INSERT INTO `trm` VALUES ('13', '3', '11');
INSERT INTO `trm` VALUES ('14', '3', '13');
INSERT INTO `trm` VALUES ('15', '4', '1');
INSERT INTO `trm` VALUES ('16', '4', '7');
INSERT INTO `trm` VALUES ('17', '4', '8');
INSERT INTO `trm` VALUES ('18', '4', '9');
INSERT INTO `trm` VALUES ('19', '4', '17');
INSERT INTO `trm` VALUES ('20', '4', '10');
INSERT INTO `trm` VALUES ('21', '4', '15');

-- ----------------------------
-- Table structure for trole
-- ----------------------------
DROP TABLE IF EXISTS `trole`;
CREATE TABLE `trole` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rolename` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of trole
-- ----------------------------
INSERT INTO `trole` VALUES ('1', '营业部经理');
INSERT INTO `trole` VALUES ('2', '副总经理');
INSERT INTO `trole` VALUES ('3', '业务员');
INSERT INTO `trole` VALUES ('4', '公司财务');

-- ----------------------------
-- Table structure for tur
-- ----------------------------
DROP TABLE IF EXISTS `tur`;
CREATE TABLE `tur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `rid` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tur
-- ----------------------------
INSERT INTO `tur` VALUES ('1', '1', '1');
INSERT INTO `tur` VALUES ('2', '2', '2');
INSERT INTO `tur` VALUES ('3', '3', '3');
INSERT INTO `tur` VALUES ('4', '4', '3');
INSERT INTO `tur` VALUES ('5', '5', '4');

-- ----------------------------
-- Table structure for tuser
-- ----------------------------
DROP TABLE IF EXISTS `tuser`;
CREATE TABLE `tuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uname` varchar(255) NOT NULL,
  `upwd` varchar(255) NOT NULL,
  `realname` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tuser
-- ----------------------------
INSERT INTO `tuser` VALUES ('1', 'lixiaoshan', '123456', '李晓珊', '40');
INSERT INTO `tuser` VALUES ('2', 'chenguoji', '123456', '陈国基', '45');
INSERT INTO `tuser` VALUES ('3', 'changkaining', '123456', '常凯宁', '28');
INSERT INTO `tuser` VALUES ('4', 'lijian', '123456', '李健', '26');
INSERT INTO `tuser` VALUES ('5', 'zhanglin', '123456', '张琳', '30');
